# R3 checks not established

## R4 additions (Mi'mar, 17 October 2026)

- **R4-3 focus screen:** checked in real Chrome 154 headless on Mi'mar's box (test-only, unpinned browser; `test-results/r4/R4-3-chrome-*.log`). Colours are composited over white, so a translucent focus background on a dark page can be under-measured (false fail, never a false pass relative to R3). The 3:1 threshold is a screening choice for reviewers to confirm; it does not prove WCAG 2.4.7/2.4.11/2.4.13 or 1.4.11.
- **R4-4 browser support tree:** `supportTreeDigest` was checked on unit fixtures and as a stability probe on the box's stock `/opt/google/chrome` (non-protected mode). Protected mode correctly refuses that stock install (owner-writable files). A provisioned root-owned read-only browser directory under `/opt/fannan/bin/` is UNTESTED (none exists); a setuid `chrome-sandbox` would need mode 4555, not 4755.
- **Positive path of the launcher's protected-storage check:** still UNTESTED (needs a root-owned `/opt/fannan/bin`).
- **R4-6 unitless spacing:** unchanged; awaiting Fadel's decision.


Fresh executed results are in `VERIFICATION.md` and `test-results/r3/`; R2 logs are historical, not R3 PASS. The final branch response quotes every command/count and each failure. Expected rejection, SKIP, blocked prerequisite and actual PASS are distinct.

- **Dependency-backed converter/build success and browser fixture: BLOCKED.** No complete existing runtime-deps tree is available. Offline-only locked restore failed ENOTCACHED for zwitch-2.0.4; no network install ran. Pure validator and malformed-token build subprocess regressions run. Family-array/percentage line-height success through real Style Dictionary remains untested.
- **Production GNU/Linux guard/launcher/manifest integration: SKIP/unsupported on Darwin.** Linux openat2, GNU stat/hash, environment sanitization and full detector execution require the target host. Exact argv and canonical parser behavior run using clearly isolated platform adapters; they do not prove Linux utilities. Negative root/shared-owner boundary unit tests do run.
- **Actual browser focus rendering: NOT ESTABLISHED.** Chrome CLI attempt with an isolated temporary profile aborted with signal 6 in sandbox. Before/after computed-style logic is unit-tested; real browser/WCAG/manual focus, appearance contrast, overlays and screenshot behavior remain untested. No no-sandbox fallback was used.
- **Browser identity: BLOCKED by missing reviewed pin.** No version/hash/path was invented. Protected ancestry and override/pin rejection tests run; target actual executable/support tree is not supplied.
- **Protected storage, identity and same-uid exclusion: OPEN.** No user/service/permission/OS changes, root-owned deployment install or hostile same-identity race proof ran. Existing safe-writer security requirements remain mandatory. Dedicated user vs reviewed sandbox requires Fadel/system owner/Amin.
- **Real detector/full gate/HANDOFF success: BLOCKED.** Original pinned binary/support assets are absent. No fake binary, stub or skipped test is counted as production success.
- **Target Node history:** v22.23.3 installed on Mi'mar's box and matching archive hash are reported in the supplied review; Amin's GPG result is reported-only and source absent. No live target access or redundant reinstall ran; package flags stay false.
- **B3/Jabr token/branch/daily task: NOT RUN.** No credentials read, no mutation probe or other token tried. Need authoritative permission/repository-selection/safe-read method and actual original proof/task metadata; 403/422 inference is insufficient.
- **Amin final review and Fadel yes: OPEN.** No sign-off, consent or approval on changed bytes was obtained or fabricated; approval remains in Fannan's own chat.
- **Host hold/activation/rollback and live callers/memory: NOT RUN.** No host API supplied, no installer guessed, no memory or installed skills changed. Exact all-or-none fault recovery remains unproven.
- **Paid runtime gate/provider operations/real pilot: NOT RUN.** No paid call, provider connection, live skill loading, signed project design/claim/licence validation, real assistive technology, RTL/long text, declared desktop width/reflow, engineer handoff or QA build ran. Text/DOM screening does not prove taste, truth or WCAG conformance.
- **Missing historical sources:** original retired-routines, helper/13 tests, external register/full plan and Amin r7 record were not found by repository filename search. No external/Drive search or reconstruction was attempted.
- **External static tools:** semgrep, shellcheck and gitleaks are unavailable. Syntax/diff checks and a redacting secret-pattern scan run; they are not a comprehensive secrets/security audit.
- **Archived R2 suites:** executed separately unchanged; their Node and Python unit suites pass with the historical Linux skip; their browser fixture fails from absent dependencies, recorded as an actual blocked command rather than an R3 regression or pass.
