// Isolated browser fixture: copied tools get a TEST root shim because production write guards target /workspace on Linux.
// This proves Node/Chrome/Style Dictionary execution, never production guard or a real project PASS.
import { cpSync, mkdirSync, writeFileSync, readFileSync, existsSync, mkdtempSync, chmodSync, realpathSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { execFileSync, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { criticRows, manualIds, states } from '../tools/handoff-contract.mjs';
import { tmpdir } from 'node:os';
import { fixturePage } from './fixture-page.mjs';

const task = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const deps = join(task, 'runtime-deps');
if (!['yaml/dist/index.js', 'style-dictionary/lib/StyleDictionary.js', 'playwright-core/index.mjs', 'axe-core/axe.min.js', '@google/design.md/dist/index.js'].every(name => existsSync(join(deps, 'node_modules', name)))) {
  console.error('LOCAL FIXTURE BLOCKED: existing pinned runtime dependencies absent; no network install attempted'); process.exit(2);
}
const chrome = process.platform === 'darwin' ? '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' : '/usr/bin/google-chrome';
if (!existsSync(chrome)) { console.error('LOCAL FIXTURE BLOCKED: local test browser absent'); process.exit(2); }
const fixture = mkdtempSync(join(tmpdir(), 'fannan-browser-fixture-'));
console.log('TEST-ONLY fixture evidence: ' + fixture);
const tools = join(fixture, 'tools');
const output = join(fixture, 'design-output/test');
mkdirSync(output, { recursive: true });
cpSync(join(task, 'release/tools'), tools, { recursive: true, force: true });
cpSync(join(task, 'release/runtime/sd.config.mjs'), join(fixture, 'runtime/sd.config.mjs'), { recursive: true, force: true });
cpSync(join(task, 'release/runtime/package-lock.json'), join(fixture, 'runtime/package-lock.json'), { recursive: true, force: true });
cpSync(join(task, 'release/runtime/quality-checks.json'), join(fixture, 'runtime/quality-checks.json'), { recursive: true, force: true });
cpSync(join(task, 'release/runtime/dependency-trust.json'), join(fixture, 'runtime/dependency-trust.json'), { recursive: true, force: true });
const root = join(fixture, 'design-output');
// CODEX-R3-03: every relocation must apply, or the fixture stops (no silent no-op replacement).
const patch = (file, from, to) => { const text = readFileSync(file, 'utf8'); if (!text.includes(from)) throw Error(`fixture patch target absent in ${file}`); writeFileSync(file, text.replace(from, to)); };
const checker = join(tools, 'pre-handoff-check.mjs');
patch(checker, "const OUTPUT_BASE = '/workspace/design-output';", `const OUTPUT_BASE = ${JSON.stringify(root)};`);
// CODEX-R3-03: the temporary launcher copy gets the same test root, so detect reaches the pinned-binary check.
// The production launcher in release/tools keeps its /workspace/design-output boundary (checked below).
const launcherBoundary = '"/workspace/design-output/$FANNAN_PROJECT"/*)';
if (!readFileSync(join(task, 'release/tools/launcher-impeccable.sh.internal'), 'utf8').includes(launcherBoundary)) throw Error('production launcher boundary changed');
patch(join(tools, 'launcher-impeccable.sh.internal'), launcherBoundary, `${JSON.stringify(realpathSync(root) + '/')}"$FANNAN_PROJECT"/*)`);
const missingBinary = 'impeccable (Fannan launcher): pinned binary missing; no download fallback';
const runChecker = (evidenceDir, quiet = false, extra = []) => {
  const r = spawnSync(process.execPath, [join(tools, 'pre-handoff-check.mjs'), design, html, evidenceDir, 'test', handoff, ...extra], { env, encoding: 'utf8' });
  if (!quiet) { process.stdout.write(r.stdout); process.stderr.write(r.stderr); }
  const result = JSON.parse(readFileSync(join(evidenceDir, 'evidence.json'), 'utf8'));
  // CODEX-R3-03: the full gate must stop at the missing pinned binary (launcher exit 3), not at any other detector error.
  if (result.checks.impeccable?.exit !== 3 || result.checks.impeccable.ran !== false || !r.stderr.split('\n').includes(missingBinary)) throw Error(`expected launcher exit 3 "${missingBinary}"; got exit ${result.checks.impeccable?.exit}: ${r.stderr.trim().split('\n').filter(l => l.includes('impeccable')).join(' | ')}`);
  return { status: r.status, result };
};
const guard = `#!${process.execPath}\nconst fs=require('fs'),path=require('path');const root=${JSON.stringify(root)};const [a,b]=process.argv.slice(2);const write=process.argv[1].endsWith('safe-write.sh');const project=write?a:b,target=path.resolve(write?b:a);if(project!=='test'||!target.startsWith(path.join(root,project)+path.sep)){console.error('TEST GUARD DENY');process.exit(10)}if(write){fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,fs.readFileSync(0),{flag:'wx'});}else console.log('TEST GUARD ALLOW');\n`;
writeFileSync(join(tools, 'readonly-precheck.sh'), guard, { mode: 0o755 });
writeFileSync(join(tools, 'safe-write.sh'), guard, { mode: 0o755 });
chmodSync(join(tools, 'readonly-precheck.sh'), 0o755);
chmodSync(join(tools, 'safe-write.sh'), 0o755);
// R6: the test shim carries the local Chrome's own version, so the R4-4 runtime-version check can pass in this fixture.
const chromeVersion = /(\d+\.\d+\.\d+\.\d+)/.exec(execFileSync(realpathSync(chrome), ['--version'], { encoding: 'utf8' }))?.[1];
if (!chromeVersion) throw Error('local Chrome version unreadable');
// These adapters exist only in the temporary copied tools; they cannot approve production storage.
const verifier = join(tools, 'verify-deps.mjs');
writeFileSync(verifier, readFileSync(verifier, 'utf8').replace('return verifyDeps(prefix, pin, releaseRoot);', 'return verifyDependencyTree(prefix, pin, releaseRoot);'));
writeFileSync(join(tools, 'executable-trust.mjs'), readFileSync(join(tools, 'executable-trust.mjs'), 'utf8').replace('export function verifiedBrowser() {', 'function productionBrowser() {') + `\nexport function verifiedBrowser() { return { ...verifyExecutable(${JSON.stringify({path:realpathSync(chrome),sha256:createHash('sha256').update(readFileSync(chrome)).digest('hex')})}), version: ${JSON.stringify(chromeVersion)} }; }\n`);
const env = { ...process.env, FANNAN_DEPS: deps };
delete env.CHROME_PATH; delete env.PUPPETEER_EXECUTABLE_PATH;
const sourceDesign = readFileSync(resolve(task, 'input/fannan-review-pack/example-DESIGN.md'), 'utf8');
const design = join(output, 'fixture-DESIGN.md');
writeFileSync(design, sourceDesign.replace('---\n\n## Overview', 'breakpoints:\n  desktop: 1440px\n---\n\n## Overview'));
const json = join(output, 'tokens.json'), css = join(output, 'variables.css');
execFileSync(process.execPath, [join(tools, 'designmd-to-sd.mjs'), design, json, 'test'], { env, stdio: 'inherit' });
execFileSync(process.execPath, [join(tools, 'sd-build.mjs'), json, css, 'test'], { env, stdio: 'inherit' });
if (!readFileSync(css, 'utf8').includes('--colors-primary') || !readFileSync(css, 'utf8').includes('--breakpoints-desktop')) throw Error('CSS token or breakpoint absent');
const html = join(output, 'home.html');
writeFileSync(html, fixturePage('variables.css')); // OPUS-R2-10 follow-up: built spacing scale, no browser defaults
const handoff = join(output, 'handoff.json');
writeFileSync(handoff, '{}'); // Deliberately fails contract: this fixture only tests browser execution.
const evidence = join(output, 'evidence');
let { status, result } = runChecker(evidence);
if (status !== 1 || result.pass || !result.checks.axe || !result.checks.design || !result.checks.impeccable) throw Error('expected browser execution and fail-closed output');
const shot = join(evidence, 'page-1440.png');
const hash = createHash('sha256').update(readFileSync(shot)).digest('hex');
const brief = join(output, 'brief.md'), rules = join(output, 'rules.md'), settings = join(output, 'settings.md'), approved = join(output, 'approval.md');
writeFileSync(brief, 'Residents need a clear service.\nSpecific service\nA service for residents.\nStart\n');
writeFileSync(rules, 'Use verified copy.');
writeFileSync(settings, 'repo-fixture stack-fixture engineer-fixture qa-fixture writer-fixture approver-fixture');
const frameId = `home/en/default/v1/${hash}`;
writeFileSync(approved, `2026-10-16 approver-fixture ${frameId}`);
const na = state => ({ state, lang: 'en', dir: 'ltr', applicable: false, reason: 'fixture static state', reviewer: 'fixture-reviewer', evidence: shot });
const authored = {
  version: 1, phase: 'handoff', brief: { path: brief }, rules: { path: rules },
  designLink: { url: 'https://example.invalid/private', private: true, evidence: brief }, tokens: { ...Object.fromEntries(['json', 'css', 'buildScript', 'config', 'lock'].map(k => { const path = { json, css, buildScript: join(tools, 'sd-build.mjs'), config: join(fixture, 'runtime/sd.config.mjs'), lock: join(fixture, 'runtime/package-lock.json') }[k]; return [k, { path, sha256: createHash('sha256').update(readFileSync(path)).digest('hex') }]; })), buildEvidence: { path: css + '.build.json' } }, toolEvidence: [{ tool: 'fixture', version: '1', artifact: shot }],
  settings: { desktopWidths: [1440], path: settings, repository: 'repo-fixture', stack: 'stack-fixture', roles: { engineer: 'engineer-fixture', qaGate: 'qa-fixture', writer: 'writer-fixture', approver: 'approver-fixture' } },
  pointOfView: { idea: 'Clear service for residents', briefRefs: ['brief.md:1'] },
  screens: [{ id: 'home', page: html, headingOutline: [{ level: 1, text: 'Specific service' }], seoIntent: 'service', schemaIntent: 'none', images: [], actions: [{ id: 'start', label: 'Start' }], states: [{ state: 'default', lang: 'en', dir: 'ltr', page: html, frame: { path: shot, width: 1440, version: 'v1', sha256: hash } }, ...states.slice(1).map(na)], components: [{ id: 'start-button', states: [{ state: 'default', lang: 'en', dir: 'ltr', applicable: true, evidence: shot }, ...states.slice(1).map(na)] }], acceptance: [{ id: 'visible', severity: 'BLOCK', decision: 'PASS', check: 'service visible', evidence: shot }], wcag: { standard: '2.2 AA', contrastEvidence: shot, focusOrderEvidence: shot, targetSizeEvidence: shot } }],
  copySlots: [
    { id: 'headline', screen: 'home', kind: 'interface', purpose: 'name service', text: 'Specific service', minChars: 5, maxChars: 32, tone: 'direct', placementScreenshot: shot, placements: [{ lang: 'en', state: 'default', screenshot: shot }], source: { kind: 'brief', path: brief, ref: 'brief.md:2' }, lang: 'en', dir: 'ltr', variants: [{ lang: 'en', dir: 'ltr', text: 'Specific service', source: { path: brief, ref: 'brief.md:2' } }] },
    { id: 'description', screen: 'home', kind: 'interface', purpose: 'explain service', text: 'A service for residents.', minChars: 5, maxChars: 40, tone: 'direct', placementScreenshot: shot, placements: [{ lang: 'en', state: 'default', screenshot: shot }], source: { kind: 'brief', path: brief, ref: 'brief.md:3' }, lang: 'en', dir: 'ltr', variants: [{ lang: 'en', dir: 'ltr', text: 'A service for residents.', source: { path: brief, ref: 'brief.md:3' } }] },
    { id: 'button', screen: 'home', kind: 'interface', purpose: 'start flow', text: 'Start', minChars: 1, maxChars: 20, tone: 'direct', placementScreenshot: shot, placements: [{ lang: 'en', state: 'default', screenshot: shot }], source: { kind: 'brief', path: brief, ref: 'brief.md:4' }, lang: 'en', dir: 'ltr', variants: [{ lang: 'en', dir: 'ltr', text: 'Start', source: { path: brief, ref: 'brief.md:4' } }] }
  ],
  facts: [], placeholders: [], openQuestions: [], languages: [{ lang: 'en', dir: 'ltr' }], assets: [], motion: [],
  components: [{ id: 'start-button', variants: ['primary'], states: ['default'], tokens: { background: 'colors.primary', label: 'typography.label' }, behaviour: 'starts the service flow; one per viewport' }],
  manualChecks: manualIds.map(id => ({ id, screen: 'home', lang: 'en', state: 'default', decision: 'PASS', reviewer: 'fixture-reviewer', artifact: shot, note: 'test fixture only', briefRefs: ['brief.md:1'] })),
  critic: { referenceWork: shot, rounds: [{ decision: 'PASS', reviewer: 'fixture-critic', evidence: shot, copyChecks: [{ row: 'copy-truth', decision: 'PASS', evidence: shot }], designChecks: criticRows.filter(row => row !== 'copy-truth').map(row => ({ row, decision: 'PASS', evidence: shot })), componentComparison: { screens: ['home'], decision: 'PASS', evidence: shot } }] },
  approval: { decision: 'approved', approver: 'approver-fixture', record: approved, frameIds: [frameId] }
};
writeFileSync(handoff, JSON.stringify(authored));
const evidence2 = join(output, 'evidence-valid');
const { status: status2, result: second } = runChecker(evidence2);
status = status2;
if (status !== 1 || !second.checks.contract.pass || second.checks.states.length !== 1 || !second.checks.states[0].pass || second.checks.impeccable.pass) throw Error('expected valid contract and all applicable state browser checks, with pinned binary blocking');
if (!second.checks.widths?.pass || second.checks.states[0].widths?.results.map(r => r.width).join() !== '1440,320' || !second.checks.states[0].widths.pass) throw Error('R8: declared desktop width 1440 and 320 px reflow must be screened on the page and the state');
// R12 M18: the claims VERIFICATION.md makes about this run are asserted here, not inferred.
const claims = { integrity: second.checks.integrity?.status, stateIntegrity: second.checks.states[0].integrity?.status, glassSource: second.checks.glassSource?.pass, accent: second.checks.accent?.status, stateAccent: second.checks.states[0].accent?.status, frames: second.checks.frames?.status, spacingExceptions: second.checks.spacingExceptions?.status, reflowCandidates: second.checks.reflowCandidates?.status, stylesheets: second.checks.stylesheets?.pass, stateStylesheets: second.checks.states[0].stylesheets?.pass, reducedMotion: second.checks.reducedMotion?.pass, stateReducedMotion: second.checks.states[0].reducedMotion?.pass, stateRafCounted: Number.isFinite(second.checks.states[0].reducedMotion?.rafCallsOver700ms) };
console.log('R12/R13 fixture claims: ' + JSON.stringify(claims));
if (!second.checks.integrity?.pass || !second.checks.states[0].integrity?.pass || second.checks.glassSource?.pass !== true || !second.checks.accent?.pass || second.checks.accent.status !== 'PASS' || !second.checks.states[0].accent?.pass || second.checks.states[0].accent.status !== 'PASS' || !second.checks.frames?.pass || !second.checks.spacingExceptions?.pass || !claims.stylesheets || !claims.stateStylesheets || !claims.reducedMotion || !claims.stateReducedMotion || !claims.stateRafCounted) throw Error('R12 M18, R13 N07/N18: integrity (page and state), glassSource, accent (page and state), frames and spacingExceptions must PASS on the valid fixture: ' + JSON.stringify(claims));
if (process.env.FANNAN_FIXTURE_EVIDENCE_COPY) cpSync(join(evidence2, 'evidence.json'), process.env.FANNAN_FIXTURE_EVIDENCE_COPY);
// R13 N05/N06: executed negative runs of the frames, spacing-exception and per-state integrity gates (not source regexes).
const original = readFileSync(html, 'utf8');
const negative = {};
writeFileSync(html, original.replace('</main>', '<iframe title="embedded note" srcdoc="<p>note</p>"></iframe></main>'));
const { result: framed } = runChecker(join(output, 'evidence-frame'), true);
const { result: framedWire } = runChecker(join(output, 'evidence-frame-wireframe'), true, ['--phase=wireframe']);
negative.frames = { handoff: framed.checks.frames?.status, statePass: framed.checks.states[0]?.frames?.pass, wireframe: framedWire.checks.frames?.status };
if (framed.checks.frames?.status !== 'FAIL' || framed.checks.frames.pass !== false || framed.pass || framed.checks.states[0]?.frames?.pass !== false || framedWire.checks.frames?.status !== 'DEFERRED') throw Error('R13 N05: a same-origin srcdoc frame must FAIL the handoff (page and state) and be DEFERRED in a wireframe: ' + JSON.stringify(negative.frames));
writeFileSync(html, original.replace('<h1 data-copy-slot="headline">', '<h1 id="title" data-copy-slot="headline" data-fannan-spacing-exception="optical alignment of the title" style="margin-left:3px">'));
const { result: excused } = runChecker(join(output, 'evidence-spacing-unapproved'), true);
writeFileSync(handoff, JSON.stringify({ ...authored, spacingExceptions: [{ screen: 'home', state: 'default', lang: 'en', id: 'title', reason: 'optical alignment of the title', reviewer: 'approver-fixture' }] }));
const { result: approvedExc } = runChecker(join(output, 'evidence-spacing-approved'), true);
negative.spacingExceptions = { withoutEntry: excused.checks.spacingExceptions?.status, unresolved: excused.checks.spacingExceptions?.unresolved?.length, withEntry: approvedExc.checks.spacingExceptions?.status, contractWithEntry: approvedExc.checks.contract?.pass };
if (excused.checks.spacingExceptions?.status !== 'FAIL' || excused.pass || approvedExc.checks.spacingExceptions?.status !== 'PASS' || !approvedExc.checks.contract?.pass) throw Error('R13 N05: a spacing exception without an approver entry must FAIL, and PASS with a matching entry: ' + JSON.stringify(negative.spacingExceptions));
writeFileSync(html, original);
const statePage = join(output, 'loading.html');
writeFileSync(statePage, original.replace('</main>', '<div id="wide" style="width:2000px;height:1px"></div></main><script>document.getElementById("wide").remove();</script>'));
const twoStates = JSON.parse(JSON.stringify(authored));
twoStates.screens[0].states[states.indexOf('loading')] = { state: 'loading', lang: 'en', dir: 'ltr', page: statePage, frame: { path: shot, width: 1440, version: 'v1', sha256: hash } };
writeFileSync(handoff, JSON.stringify(twoStates));
const { result: stateOnly } = runChecker(join(output, 'evidence-state-integrity'), true);
const loadingState = stateOnly.checks.states.find(x => x.state === 'loading'), defaultState = stateOnly.checks.states.find(x => x.state === 'default');
negative.stateIntegrity = { positional: stateOnly.checks.integrity?.status, defaultState: defaultState?.integrity?.status, loadingState: loadingState?.integrity?.status, loadingMismatch: loadingState?.integrity?.mismatches?.map(m => m.check), loadingPass: loadingState?.pass };
if (stateOnly.checks.integrity?.status !== 'PASS' || defaultState?.integrity?.status !== 'PASS' || loadingState?.integrity?.status !== 'integrity mismatch' || loadingState.pass !== false || stateOnly.pass) throw Error('R13 N06: an integrity mismatch on a non-positional state must fail that state while the positional page passes: ' + JSON.stringify(negative.stateIntegrity));
console.log('R13 fixture negative runs: ' + JSON.stringify(negative));
// R14-GPT-05: timer-driven motion inside an open shadow root fails reduced motion, on the positional page and on a
// declared state (executed checker runs; the host box does not move, there is no rAF and no Web Animation).
const shadowMotion = '<div id="motion"></div><script>const mr = document.getElementById("motion").attachShadow({ mode: "open" }); mr.innerHTML = \'<span style="display:inline-block;width:12px;height:12px;background:#000"></span>\'; let mx = 0; setInterval(() => { mx += 4; mr.firstChild.style.transform = "translateX(" + mx + "px)"; }, 50);</script>';
writeFileSync(handoff, JSON.stringify(authored));
writeFileSync(html, original.replace('</main>', shadowMotion + '</main>'));
const { result: movingPage } = runChecker(join(output, 'evidence-shadow-motion-page'), true);
writeFileSync(html, original);
writeFileSync(statePage, original.replace('</main>', shadowMotion + '</main>'));
writeFileSync(handoff, JSON.stringify(twoStates));
const { result: movingState } = runChecker(join(output, 'evidence-shadow-motion-state'), true);
const movingLoading = movingState.checks.states.find(x => x.state === 'loading'), movingDefault = movingState.checks.states.find(x => x.state === 'default');
const motionRuns = { page: { pass: movingPage.checks.reducedMotion?.pass, changed: movingPage.checks.reducedMotion?.elementsChangedOver700ms, raf: movingPage.checks.reducedMotion?.rafCallsOver700ms }, state: { positional: movingState.checks.reducedMotion?.pass, defaultState: movingDefault?.reducedMotion?.pass, loading: movingLoading?.reducedMotion?.pass, loadingChanged: movingLoading?.reducedMotion?.elementsChangedOver700ms, loadingStatePass: movingLoading?.pass } };
console.log('R14 fixture shadow-motion runs: ' + JSON.stringify(motionRuns));
if (movingPage.checks.reducedMotion?.pass !== false || !(movingPage.checks.reducedMotion.elementsChangedOver700ms > 0) || movingPage.pass || movingState.checks.reducedMotion?.pass !== true || movingDefault?.reducedMotion?.pass !== true || movingLoading?.reducedMotion?.pass !== false || movingLoading.pass !== false) throw Error('R14-GPT-05: shadow-root timer motion must fail reduced motion on the page and on the state that has it: ' + JSON.stringify(motionRuns));
// R16 (panel round 16): full pre-handoff runs for R16-GPT-01/02 (positional page and its declared state) and the
// wireframe-phase coverage of R16-GPT-03. Results are collected first so a checker without the fixes shows every gap.
writeFileSync(handoff, JSON.stringify(authored));
const r16 = {};
const r16Run = (name, extraHtml, script) => {
  writeFileSync(html, original.replace('</main>', `${extraHtml}</main><script>${script}</script>`));
  const { result } = runChecker(join(output, `evidence-r16-${name}`), true);
  const state = result.checks.states.find(x => x.state === 'default');
  return { page: result.checks.integrity?.status, state: state?.integrity?.status, checks: [...new Set([...(result.checks.integrity?.mismatches || []), ...(state?.integrity?.mismatches || [])].map(m => `${m.check}/${m.source || 'world'}`))].sort(), pass: result.pass };
};
r16.filterReveal = r16Run('filter', '<p id="r16f" style="filter:blur(8px)">Revealed later</p>', 'document.getElementById("r16f").style.filter = "none";');
r16.fadedSubmit = r16Run('submit', '<input id="r16s" type="submit" value="Start now" style="opacity:.05">', 'document.getElementById("r16s").style.opacity = "1";');
r16.scriptedLabel = r16Run('label', '<label id="r16l" for="r16e"></label><input id="r16e" type="email">', 'document.getElementById("r16l").textContent = "Email address";');
writeFileSync(html, original);
const aboutPage = join(output, 'about.html');
writeFileSync(aboutPage, original.replace('</main>', '<h1>Second top heading</h1></main>'));
const wide = JSON.parse(JSON.stringify(authored));
wide.languages = [{ lang: 'en', dir: 'ltr' }, { lang: 'ar', dir: 'rtl' }];
wide.screens.push({ ...JSON.parse(JSON.stringify(authored.screens[0])), id: 'about', page: aboutPage, states: [{ state: 'default', lang: 'en', dir: 'ltr', page: aboutPage }] });
writeFileSync(handoff, JSON.stringify(wide));
const { result: wideWire } = runChecker(join(output, 'evidence-r16-wireframe-coverage'), true, ['--phase=wireframe']);
const scopeOf16 = (screen, lang) => wideWire.checks.states.find(x => x.screen === screen && x.lang === lang);
r16.wireframe = { homeEn: scopeOf16('home', 'en')?.pass, homeAr: scopeOf16('home', 'ar')?.error, aboutEn: scopeOf16('about', 'en')?.pass, aboutAr: scopeOf16('about', 'ar')?.error, contractNamesAbout: (wideWire.checks.contract?.errors || []).some(e => /manual about\/ar\/wireframe/.test(e)), pass: wideWire.pass };
writeFileSync(handoff, JSON.stringify(authored));
console.log('R16 fixture runs: ' + JSON.stringify(r16));
const r16Want = {
  filterReveal: r16.filterReveal.page === 'INCOMPLETE' && r16.filterReveal.state === 'INCOMPLETE' && r16.filterReveal.pass === false,
  fadedSubmit: r16.fadedSubmit.page === 'integrity mismatch' && r16.fadedSubmit.checks.includes('contrastFailures/js-off') && r16.fadedSubmit.pass === false,
  scriptedLabel: r16.scriptedLabel.page !== 'PASS' && r16.scriptedLabel.checks.includes('content/js-off') && r16.scriptedLabel.pass === false,
  wireframe: r16.wireframe.homeEn !== undefined && r16.wireframe.aboutEn === false && /no rendering declared/.test(r16.wireframe.homeAr || '') && /no rendering declared/.test(r16.wireframe.aboutAr || '') && r16.wireframe.contractNamesAbout && r16.wireframe.pass === false,
};
if (Object.values(r16Want).some(v => !v)) throw Error('R16-GPT-01/02/03 full-run expectations failed: ' + JSON.stringify(r16Want));
// R17 (panel round 17): full pre-handoff runs for the rendered-visibility backstop (R17-MIMAR-01/02, R17-GPT-02), the
// control value/name split (R17-GPT-01), native copy screening (R17-GPT-03) and a healthy scroll reveal (no false
// positive). Results are collected first so a checker without the fixes shows every gap.
writeFileSync(handoff, JSON.stringify(authored));
const r17 = {};
const r17Run = (name, extraHtml, script, head = '') => {
  writeFileSync(html, original.replace('</head>', `${head}</head>`).replace('</main>', `${extraHtml}</main>${script ? `<script>${script}</script>` : ''}`));
  const started = Date.now();
  const { result } = runChecker(join(output, `evidence-r17-${name}`), true);
  const state = result.checks.states.find(x => x.state === 'default');
  const vis = [result.checks.integrity?.probeWorld?.visibility, result.checks.integrity?.jsOff?.visibility];
  return { page: result.checks.integrity?.status, state: state?.integrity?.status, checks: [...new Set([...(result.checks.integrity?.mismatches || []), ...(state?.integrity?.mismatches || [])].map(m => `${m.check}/${m.source || 'world'}`))].sort(), copy: state?.copy?.errors || [], placeholders: result.checks.design?.placeholders, filler: result.checks.design?.filler, visibilityMs: vis.map(v => v?.ms ?? null), runMs: Date.now() - started, pass: result.pass };
};
r17.clipPath = r17Run('clip-path', '<p id="r17c" style="clip-path:inset(0 100% 0 0)">Revealed later</p>', 'document.getElementById("r17c").style.clipPath = "none";');
r17.scale = r17Run('scale', '<p id="r17s" style="transform:scale(.02)">Scaled in later</p>', 'document.getElementById("r17s").style.transform = "none";');
r17.preloader = r17Run('preloader', '<div id="r17p" style="position:fixed;inset:0;background:#fff"></div>', 'document.getElementById("r17p").remove();');
r17.placeholderOpacity = r17Run('placeholder', '<input id="r17i" placeholder="name@example.org">', 'document.getElementById("r17i").classList.add("ok");', '<style>#r17i::placeholder{color:#000;opacity:.05}#r17i.ok::placeholder{opacity:1}</style>');
r17.textFill = r17Run('text-fill', '<p id="r17t" style="-webkit-text-fill-color:transparent">Filled in later</p>', 'document.getElementById("r17t").style.webkitTextFillColor = "currentColor";');
r17.gradient = r17Run('gradient', '<div style="position:relative"><p>First line<br>second line<br>third line</p><div id="r17g" style="position:absolute;inset:0;background:linear-gradient(transparent,#fff 60%)"></div></div>', 'document.getElementById("r17g").remove();');
r17.ariaSubmit = r17Run('aria-submit', '<input id="r17a" type="submit" aria-label="Start now" value="">', 'document.getElementById("r17a").value = "Start now";');
r17.nativeCopy = r17Run('native-copy', '<input placeholder="[placeholder]"><input type="submit" value="Lorem ipsum">');
r17.healthyReveal = r17Run('healthy-reveal', '<p class="r17r" style="margin-top:1200px">Revealed on scroll</p>', 'const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting && e.target.classList.add("in"))); document.querySelectorAll(".r17r").forEach(e => io.observe(e));', '<style>.r17r{opacity:0;transition:opacity .6s}.r17r.in{opacity:1}</style><noscript><style>.r17r{opacity:1}</style></noscript>');
writeFileSync(html, original);
writeFileSync(handoff, JSON.stringify(authored));
console.log('R17 fixture runs: ' + JSON.stringify(r17));
const lost17 = r => r.page === 'integrity mismatch' && r.state === 'integrity mismatch' && r.checks.some(c => /^text(Obscured|Unreadable)\/js-off$/.test(c)) && r.pass === false;
const r17Want = {
  clipPath: lost17(r17.clipPath), scale: lost17(r17.scale), preloader: lost17(r17.preloader), placeholderOpacity: lost17(r17.placeholderOpacity), textFill: lost17(r17.textFill), gradient: lost17(r17.gradient),
  ariaSubmit: r17.ariaSubmit.page !== 'PASS' && r17.ariaSubmit.checks.includes('content/js-off') && r17.ariaSubmit.pass === false,
  nativeCopy: r17.nativeCopy.copy.some(e => /unlisted native copy: \[placeholder\]/.test(e)) && r17.nativeCopy.copy.some(e => /unlisted native copy: Lorem ipsum/.test(e)) && r17.nativeCopy.placeholders === true && r17.nativeCopy.pass === false,
  healthyReveal: r17.healthyReveal.page === 'PASS' && r17.healthyReveal.state === 'PASS',
};
if (Object.values(r17Want).some(v => !v)) throw Error('R17 full-run expectations failed: ' + JSON.stringify(r17Want));
writeFileSync(handoff, JSON.stringify(authored));
writeFileSync(html, readFileSync(html, 'utf8').replace('A service for residents.', 'Invented service copy.'));
const evidence3 = join(output, 'evidence-mutated');
const { result: mutated } = runChecker(evidence3, true);
if (mutated.checks.states[0].copy.pass || mutated.checks.states[0].renderedSha256 === hash) throw Error('changed HTML must fail deck and approved-frame hash');
const foreign = join(fixture, 'foreign.html');
writeFileSync(foreign, '<p>outside project</p>');
writeFileSync(html, readFileSync(html, 'utf8').replace('</main>', `<iframe src="${pathToFileURL(foreign).href}"></iframe><img src="https://example.invalid/x.png"></main>`));
const evidence4 = join(output, 'evidence-foreign');
const { result: foreignResult } = runChecker(evidence4, true);
if (!foreignResult.externalRequestsBlocked?.some(v => v.url?.includes('foreign.html')) || !foreignResult.externalRequestsBlocked?.some(v => v.url?.includes('example.invalid')) || foreignResult.checks.resourceBoundary.pass) throw Error('foreign file and network loads must be blocked by browser route');
console.log(`LOCAL FIXTURE: browser, contract and applicable state checks passed; full gate correctly blocked by absent pinned Impeccable binary (launcher exit 3: ${missingBinary})`);
