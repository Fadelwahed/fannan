import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, rmSync, symlinkSync, realpathSync, mkdirSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { assertProtectedMetadata, verifyExecutable, verifiedBrowser, supportTreeDigest, verifyBrowserPin, assertBrowserPinLocation } from '../tools/executable-trust.mjs';

test('protected storage rejects shared ownership, writable modes and links', () => {
  const meta = (uid, mode, link = false, type = 'directory') => ({ uid, mode, isSymbolicLink: () => link, isDirectory: () => type === 'directory', isFile: () => type === 'file' });
  assert.doesNotThrow(() => assertProtectedMetadata(meta(0, 0o755), '/opt'));
  for (const m of [meta(1000, 0o555), meta(0, 0o775), meta(0, 0o755, true)])
    assert.throws(() => assertProtectedMetadata(m, '/opt'), /protected/);
  assert.throws(() => assertProtectedMetadata(meta(0, 0o644, false, 'file'), '/opt/deps/file', true), /read-only/);
  assert.throws(() => assertProtectedMetadata(meta(0, 0o555, false, 'file'), '/opt/deps'), /wrong type/);
  assert.throws(() => assertProtectedMetadata(meta(0, 0o555), '/opt/deps/browser', true), /wrong type/);
});
test('executable identity requires exact bytes and a real absolute file', () => {
  const dir = mkdtempSync(join(tmpdir(), 'fannan-exec-'));
  try {
    const path = join(realpathSync(dir), 'browser'); writeFileSync(path, 'reviewed');
    const pin = { path, sha256: createHash('sha256').update('reviewed').digest('hex') };
    assert.equal(verifyExecutable(pin).sha256, pin.sha256);
    writeFileSync(path, 'modified');
    assert.throws(() => verifyExecutable(pin), /hash mismatch/);
    assert.throws(() => verifyExecutable({ ...pin, sha256: null }), /pin missing/);
    symlinkSync(path, join(dir, 'alias'));
    assert.throws(() => verifyExecutable({ ...pin, path: join(dir, 'alias') }), /symlink/);
    const nested = join(realpathSync(dir), 'nested'); mkdirSync(nested);
    writeFileSync(join(nested, 'browser'), 'reviewed');
    symlinkSync(nested, join(dir, 'nested-alias'));
    assert.throws(() => verifyExecutable({ ...pin, path: join(dir, 'nested-alias', 'browser') }), /canonical/);
    assert.throws(() => verifyExecutable({ ...pin, path: `${dir}/nested-alias/../browser` }), /canonical/);
    assert.throws(() => verifyExecutable({ ...pin, path: `${nested}/../browser` }), /canonical/);
    assert.throws(() => verifyExecutable({ ...pin, path: 'relative' }), /absolute/);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
test('production browser refuses an environment override before execution', () => {
  const old = process.env.CHROME_PATH;
  try { process.env.CHROME_PATH = '/tmp/not-a-browser'; assert.throws(verifiedBrowser, /override/); }
  finally { if (old === undefined) delete process.env.CHROME_PATH; else process.env.CHROME_PATH = old; }
});
test('production browser remains blocked without a reviewed target-host pin', () => {
  assert.throws(verifiedBrowser, /pin blocked/);
});

test('R4-4: browser support tree is hashed and any changed, added or escaping entry is refused', () => {
  const dir = realpathSync(mkdtempSync(join(tmpdir(), 'fannan-browser-')));
  try {
    const tree = join(dir, 'chrome-154'); mkdirSync(join(tree, 'locales'), { recursive: true });
    writeFileSync(join(tree, 'chrome'), 'reviewed-exe'); writeFileSync(join(tree, 'resources.pak'), 'pak'); writeFileSync(join(tree, 'locales', 'en-US.pak'), 'en');
    const pin = { path: join(tree, 'chrome'), sha256: createHash('sha256').update('reviewed-exe').digest('hex'), version: '154.0.8037.97', supportTreeSha256: supportTreeDigest(tree) };
    assert.equal(supportTreeDigest(tree), pin.supportTreeSha256, 'digest is deterministic');
    assert.equal(verifyBrowserPin(pin, false).supportTreeSha256, pin.supportTreeSha256);
    assert.throws(() => verifyBrowserPin({ ...pin, supportTreeSha256: undefined }, false), /support tree pin missing/);
    writeFileSync(join(tree, 'resources.pak'), 'tampered');
    assert.throws(() => verifyBrowserPin(pin, false), /support tree mismatch/);
    writeFileSync(join(tree, 'resources.pak'), 'pak'); writeFileSync(join(tree, 'injected.so'), 'x');
    assert.throws(() => verifyBrowserPin(pin, false), /support tree mismatch/);
    rmSync(join(tree, 'injected.so')); symlinkSync('/etc/hosts', join(tree, 'escape'));
    assert.throws(() => supportTreeDigest(tree), /escapes/);
    rmSync(join(tree, 'escape'));
    assert.equal(verifyBrowserPin(pin, false).version, '154.0.8037.97');
    assert.throws(() => supportTreeDigest(tree, true), /unprotected/, 'OPUS-R2-06: protected mode refuses a user-owned tree');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('OPUS-R2-06: browser pin location must be its own directory under /opt/fannan/bin', () => {
  assert.doesNotThrow(() => assertBrowserPinLocation('/opt/fannan/bin/chrome-154/chrome'));
  for (const path of ['/opt/fannan/bin/chrome', '/opt/fannan/binx/chrome-154/chrome', '/opt/fannan/bin/../evil/chrome', '/opt/fannan/bin/chrome-154/../chrome', 'opt/fannan/bin/chrome-154/chrome', '/usr/bin/chrome', undefined, ''])
    assert.throws(() => assertBrowserPinLocation(path), /browser/, String(path));
});

test('ARGON-R2-01: protected mode checks the support root before resolving it and refuses /opt/fannan/bin itself', () => {
  const dir = realpathSync(mkdtempSync(join(tmpdir(), 'fannan-browser-')));
  try {
    const tree = join(dir, 'chrome-154'); mkdirSync(tree); writeFileSync(join(tree, 'chrome'), 'x');
    symlinkSync(tree, join(dir, 'link'));
    assert.throws(() => supportTreeDigest(join(dir, 'link'), true), /symlink/, 'a symlinked root is refused before realpath, not after');
    assert.throws(() => supportTreeDigest('/opt/fannan/bin', true), /own directory/, 'the shared bin directory is never a support tree');
    assert.throws(() => supportTreeDigest('/opt/fannan/bin/', true), /own directory|normalised/);
    assert.throws(() => supportTreeDigest('relative/tree', true), /absolute/);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('ARGON-R2-01: protected mode refuses any symlink inside the support tree (browser-trust.json: no symlinks)', () => {
  const source = readFileSync(new URL('../tools/executable-trust.mjs', import.meta.url), 'utf8');
  assert.match(source, /if \(protectedStorage\) throw Error\(`browser support symlink forbidden/);
});

test('ARGON-R2-06: the checker launches the browser with a minimal explicit environment, never process.env', async () => {
  const mod = await import('../tools/executable-trust.mjs');
  assert.equal(typeof mod.browserLaunchEnv, 'function', 'browserLaunchEnv exported');
  process.env.FANNAN_R6_SENTINEL = 'leak';
  try {
    const env = mod.browserLaunchEnv('/tmp/fannan-home-x');
    assert.deepEqual(Object.keys(env).sort(), ['HOME', 'LANG', 'PATH']);
    assert.deepEqual(env, { PATH: '/usr/bin:/bin', LANG: 'C.UTF-8', HOME: '/tmp/fannan-home-x' });
    assert.throws(() => mod.browserLaunchEnv('relative'), /absolute/);
  } finally { delete process.env.FANNAN_R6_SENTINEL; }
  const source = readFileSync(new URL('../tools/pre-handoff-check.mjs', import.meta.url), 'utf8');
  assert.match(source, /chromium\.launch\(\{ executablePath: browserIdentity\.path, chromiumSandbox: true, env: browserLaunchEnv\(browserHome\) \}\)/);
});
