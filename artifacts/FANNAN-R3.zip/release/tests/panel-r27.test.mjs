// R27 (panel round 27): real-Chrome regressions for Mi'mar's R27 tiebreaks, confirmed by Fadel. Element identity is a
// stable key, not a position (id, else landmark + role family + accessible name + link target + order among same-key
// elements there), so a menu-open page that inserts a Close button before the links still rescues them, while footer
// copies (another landmark) never do (R27-GPT-01). Tabs to headed sections needs at least each panel's actions, counted
// only inside that tablist's sections (R27-GPT-02). Identity keeps across role changes within the action family
// (R27-GPT-03). What the source state already shows is set aside before name matching (R27-GPT-04). Each test was first
// run against the 99f4d97 sources (test-results/r27/R27-*-before.log).
import test from 'node:test';
import assert from 'node:assert/strict';
import { deflateSync } from 'node:zlib';
import { existsSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import * as integrity from '../tools/integrity.mjs';
import * as visibility from '../tools/visibility.mjs';
import { screenWidths } from '../tools/width-screen.mjs';

const { contentProbe, contrastProbe, compareIntegrity, VECTOR } = integrity;
const release = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const deps = process.env.FANNAN_DEPS || resolve(release, '..', 'runtime-deps');
const chrome = process.env.FANNAN_TEST_CHROME || '/usr/bin/google-chrome';
const haveChrome = existsSync(join(deps, 'node_modules/playwright-core')) && existsSync(chrome);
const skip = !haveChrome && 'test-only deps or local Chrome absent';
// a noisy photograph stand-in (seeded random RGB noise with soft bands), as an 8-bit RGB PNG
const photo = () => {
  const w = 320, h = 200, raw = Buffer.alloc((w * 3 + 1) * h); let seed = 7; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const o = y * (w * 3 + 1) + 1 + x * 3, base = 90 + 80 * Math.sin(x / 23) * Math.cos(y / 17); for (let c = 0; c < 3; c++) raw[o + c] = Math.max(0, Math.min(255, base + [40, 10, -20][c] + (rnd() - 0.5) * 120)); }
  const crc = b => { let c = ~0; for (const x of b) { c ^= x; for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1; } return ~c >>> 0; };
  const chunk = (t, d) => { const len = Buffer.alloc(4); len.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]), c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([len, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
};
const withBrowser = async fn => {
  const { chromium } = createRequire(join(deps, 'node_modules/'))('playwright-core');
  const { isolatedPage } = await import('../tools/probe-world.mjs');
  const dir = mkdtempSync(join(tmpdir(), 'fannan-r27-'));
  writeFileSync(join(dir, 'photo.png'), photo());
  const browser = await chromium.launch({ executablePath: chrome, args: ['--headless=new'] });
  const open = async (html, javaScriptEnabled = true) => {
    const file = join(dir, `p${Math.random().toString(36).slice(2)}.html`); writeFileSync(file, html);
    const ctx = await browser.newContext({ javaScriptEnabled, viewport: { width: 1440, height: 900 } });
    const main = await ctx.newPage(); await main.goto(pathToFileURL(file).href); await main.waitForLoadState('load'); await main.waitForTimeout(100);
    return { main, probe: await isolatedPage(main) };
  };
  try { await fn({ open }); } finally { await browser.close(); rmSync(dir, { recursive: true, force: true }); }
};
const widths = { 1440: 0, 320: 0 };
const base = Object.fromEntries(Object.entries(VECTOR).map(([k, t]) => [k, t === 'flag' ? false : t === 'text' ? '#123456' : t === 'widths' ? widths : t === 'coverage' ? 5 : 0]));
const scope = { screen: 'home', state: 'default', lang: 'en' };
const FIELDS = ['textMeasured', 'textObscured', 'textUnreadable', 'textUnmeasured', 'textHidden'];
// one rendering measured as pre-handoff-check measures it: the CSS contrast pass plus the visibility backstop
const measure = async (pg, opts) => {
  const v = { ...base, ...await pg.evaluate(contrastProbe) };
  const vis = await integrity.visibilityScan(pg, opts ? { ...integrity.VISIBILITY, ...opts } : undefined); for (const k of FIELDS) v[k] = vis[k] ?? 0; v.visibility = vis;
  return { vector: v, content: await pg.evaluate(contentProbe) };
};
const both = async (open, html) => {
  const on = await measure((await open(html)).probe), off = await measure((await open(html, false)).probe);
  return { on, off, integrity: compareIntegrity({ probe: on, page: on, jsOff: off, tamperSigns: [], scope }) };
};
const page = (body, script = '', head = '') => `<!doctype html><html lang="en"><head>${head}</head><body style="background:#fff;margin:0;font:16px/1.5 sans-serif"><main style="padding:20px"><h1>Title</h1>${body}</main>${script ? `<script>${script}</script>` : ''}</body></html>`;
const W = (body, script = '', dir = 'ltr') => `<!doctype html><html lang="${dir === 'rtl' ? 'ar' : 'en'}" dir="${dir}"><head></head><body style="background:#fff;margin:0;font:16px/1.5 sans-serif;color:#1a1a1a"><main style="padding:20px"><h1>${dir === 'rtl' ? 'عنوان' : 'Title'}</h1>${body}</main>${script ? `<script>${script}</script>` : ''}</body></html>`;

const ws = await import('../tools/width-screen.mjs');
// states: { stateName: html }; the overall result after resolving reveals, truncations and losses across the declared states
const gateOf = open => async (states, dir = 'ltr') => {
  const scopes = []; for (const [state, html] of Object.entries(states)) scopes.push({ scope: { screen: 'home', state, lang: dir === 'rtl' ? 'ar' : 'en' }, widths: await ws.screenWidths((await open(html)).main, [1440], null) });
  const r = ws.resolveReveals(scopes);
  const rules = [...new Set(scopes.flatMap(s => s.widths.results.flatMap(x => [...x.clipped.filter(c => !c.revealedBy).map(c => c.rule), ...(x.offscreenLeft.length ? ['offscreenLeft'] : []), ...((x.lost || []).filter(l => !l.reachableIn).length ? ['not shown at this width'] : [])])))].sort();
  if (process.env.DUMP) console.log(JSON.stringify(Object.keys(states)), JSON.stringify(scopes.map(s => s.widths.results.map(x => [x.width, x.clipped, x.lost, x.offscreenLeft]))).slice(0, 3000));
  return { pass: r.pass && scopes.every(s => s.widths.pass), rules };
};
const img = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1000"><rect width="1600" height="1000" fill="#7a9"/><circle cx="800" cy="500" r="300" fill="#345"/></svg>');

// the page each 'l' element is hidden below 600 px and each 's' element above it (the panel's repro pattern)
const LS = '<style>@media (max-width:600px){.l{display:none}}@media (min-width:601px){.s{display:none}}</style>';
const svgBand = (fill, patch, width) => `background:url('data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="200"><rect width="1200" height="200" fill="${fill}"/>${patch ? `<rect width="${width}" height="200" fill="${patch}"/>` : ''}</svg>`)}')`;
const P = x => W(LS + x);





test('R27-GPT-01: real Chrome: identity is a stable key: a menu-open page that inserts a Close button before the links passes (max-height:0 and display:none); a menu-open that stays collapsed fails even with footer copies (test-only)', { skip }, async () => withBrowser(async ({ open }) => {
  const gate = gateOf(open);
  const nav = (how, opened, close) => W(`<style>.nav{margin:0;padding:0;list-style:none}@media (max-width:600px){.nav{${opened ? '' : how}}}@media (min-width:601px){.menu{display:none}}</style><header><nav aria-label="Main"><button class="menu" aria-expanded="${opened}">Menu</button>${close ? '<button class="menu">Close</button>' : ''}<ul class="nav"><li><a href="/about">About</a></li><li><a href="/work">Work</a></li></ul></nav></header><p>Body copy.</p><footer><a href="/about">About</a> <a href="/work">Work</a></footer>`);
  const r = {};
  for (const [n, how] of [['maxHeight', 'max-height:0;overflow:hidden'], ['displayNone', 'display:none']]) {
    r[`${n}InsertsClose`] = (await gate({ default: nav(how, false, false), 'menu-open': nav(how, true, true) })).pass;
    r[`${n}FooterStandIn`] = (await gate({ default: nav(how, false, false), 'menu-open': nav(how, false, true) })).pass;
  }
  assert.deepEqual(r, { maxHeightInsertsClose: true, maxHeightFooterStandIn: false, displayNoneInsertsClose: true, displayNoneFooterStandIn: false });
}));

const tabsPage = (sel, { tabs, actions = {}, sections, extra = '' }) => P(`<div class="l"><div role="tablist" aria-label="Reports">${tabs.map(t => `<button role="tab" aria-selected="${t === sel}">${t}</button>`).join('')}</div><div role="tabpanel"><p>${sel} text.</p>${(actions[sel] || []).map(a => `<button>${a}</button>`).join('')}</div></div><div class="s">${sections.map(x => `<section><h2>${x.h}</h2><p>${x.h} text.</p>${(x.a || []).map(a => `<button>${a}</button>`).join('')}</section>`).join('')}</div>${extra}`);

test('R27-GPT-02: real Chrome: tabs to headed sections needs at least each panel\'s actions inside that tablist\'s sections: a sticky mobile-only Download neither breaks nor rescues the swap (test-only)', { skip }, async () => withBrowser(async ({ open }) => {
  const gate = gateOf(open);
  const sticky = '<div class="s" style="position:sticky;bottom:0"><button>Download</button></div>';
  const o = (drop, extra) => ({ tabs: ['Sales', 'Costs'], actions: { Sales: ['Download'], Costs: ['Download'] }, sections: [{ h: 'Sales', a: ['Download'] }, { h: 'Costs', a: drop ? [] : ['Download'] }], extra });
  const both = x => gate({ default: tabsPage('Sales', x), 'tab-costs': tabsPage('Costs', x) });
  assert.deepEqual({
    stickyExtra: await both(o(false, sticky)),
    noSticky: await both(o(false, '')),
    droppedWithSticky: (await both(o(true, sticky))).pass,
  }, { stickyExtra: { pass: true, rules: [] }, noSticky: { pass: true, rules: [] }, droppedWithSticky: false });
}));

test('R27-GPT-03: real Chrome: identity keeps across role changes within the action family: a toolbar whose buttons become menu items at 320 passes; an action really removed at 320 fails (test-only)', { skip }, async () => withBrowser(async ({ open }) => {
  const gate = gateOf(open);
  const bar = removeExport => W(`<style>@media (max-width:600px){.gone{display:none}}</style><div id="tb" role="toolbar" aria-label="Document"><button>Save</button> <button${removeExport ? ' class="gone"' : ''}>Export report</button></div>`, 'const mq = matchMedia("(max-width:600px)"), tb = document.getElementById("tb"); const apply = () => { tb.setAttribute("role", mq.matches ? "menu" : "toolbar"); for (const b of tb.querySelectorAll("button")) mq.matches ? b.setAttribute("role", "menuitem") : b.removeAttribute("role"); }; apply(); mq.addEventListener("change", apply);');
  assert.deepEqual({ sameNodeRole: await gate({ default: bar(false) }), actionRemoved: (await gate({ default: bar(true) })).pass }, { sameNodeRole: { pass: true, rules: [] }, actionRemoved: false });
}));

test('R27-GPT-04: real Chrome: what the source state shows is set aside before name matching: image-only slides with an undeclared slide fail even with a footer Shop now; with every slide declared they pass (test-only)', { skip }, async () => withBrowser(async ({ open }) => {
  const gate = gateOf(open);
  const car = i => W(`<div style="overflow:hidden;width:300px"><div style="display:flex;width:900px;transform:translateX(-${i * 300}px)">${[0, 1, 2].map(k => `<div style="flex:0 0 300px"><img src="${img}" alt="" style="display:block;width:300px;height:120px"><a href="/shop">Shop now</a></div>`).join('')}</div></div><footer><a href="/shop">Shop now</a></footer>`);
  assert.deepEqual({
    missingSlideFooter: (await gate({ default: car(0), 'slide-2': car(1) })).pass,
    allDeclaredFooter: await gate({ default: car(0), 'slide-2': car(1), 'slide-3': car(2) }),
  }, { missingSlideFooter: false, allDeclaredFooter: { pass: true, rules: [] } });
}));
